import warnings
import requests
import sqlite3
from bs4 import BeautifulSoup
from datetime import datetime
import pandas as pd

url = 'https://web.archive.org/web/20230908091635%20/https://en.wikipedia.org/wiki/List_of_largest_banks'
exchange_rate_file = '/home/project/TOP_10_LARGEST_BANKS/exchange_rate.csv'

csv_path = '/home/project/TOP_10_LARGEST_BANKS/Largest_banks_data.csv'
db_name = 'Banks.db'
table_name = 'Largest_banks'
log_file = 'code_log.txt'

def log_progress(message):
    dt = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(log_file, 'a') as log:
        log.write(dt + ": " + message + "\n")


def extract(url):
    html_page = requests.get(url).text
    data = BeautifulSoup(html_page,'html.parser')
    rows = data.find_all('tbody')[0].find_all('tr')

    list = []
    for row in rows:
        col = row.find_all('td')
        if len(col) != 0:
            name = col[1].find_all('a')[1].contents[0]
            MC_USD_Billion = float(col[2].contents[0])
            
            list.append({
                "Name":name,
                "MC_USD_Billion":MC_USD_Billion
                })
    
    df = pd.DataFrame(list)
    return df


def transform(df, exchange_rate_file):
    exchange_rates = pd.read_csv(exchange_rate_file)
    exchange_rates = exchange_rates.set_index(['Currency'])

    df["MC_GBP_Billion"] = round(df["MC_USD_Billion"] * exchange_rates.loc['GBP'].iloc[0],2)
    df["MC_EUR_Billion"] = round(df["MC_USD_Billion"] * exchange_rates.loc['EUR'].iloc[0],2)
    df["MC_INR_Billion"] = round(df["MC_USD_Billion"] * exchange_rates.loc['INR'].iloc[0],2)

    return df


def load_to_csv(df, csv_path):
    df.to_csv(csv_path)


def load_to_db(df,sql_connection, table_name):
    df.to_sql(table_name, sql_connection, if_exists='replace', index=False)


def run_query(query_statement, sql_connection):
    print(query_statement + ': ' + str(pd.read_sql(query_statement, sql_connection)) + '***\n')


log_progress("ETL start")
log_progress("Extraction start")
df = extract(url)
log_progress("Extraction end")
log_progress("Transform start")
df = transform(df,exchange_rate_file)
log_progress("Transform end")
log_progress("Load start")
load_to_csv(df, csv_path)
log_progress("CSV load end")
sql_connection = sqlite3.connect(db_name)
log_progress("DB connect stablished")
load_to_db(df,sql_connection, table_name)
log_progress("Data loaded to DB")
log_progress("Run queries")
run_query('SELECT * FROM Largest_banks', sql_connection)
run_query('SELECT AVG(MC_GBP_Billion) FROM Largest_banks', sql_connection)
run_query('SELECT Name from Largest_banks LIMIT 5', sql_connection)
sql_connection.close()
log_progress("DB connect closed")
log_progress("ETL end")
